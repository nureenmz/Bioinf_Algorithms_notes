import Classification.*;

/*
 * This is the application class containing the main() method
 */

public class DecisionTreeApp {
	public static void main(String[] args) {
	
/*Building a decision tree using CART (Classification & Regression Tree Algorithm*/
/*Error checking code omitted for brevity!*/
		
	System.out.println("Building CART decision tree...");
	CARTDecisionTree cart=new CARTDecisionTree();
	cart.buildTree("iris.data2_train.txt");
	
	System.out.println("Build Simple Predictions from CART Tree");
	SimplePrediction predict= new SimplePrediction(cart);
	PredictionResults p=predict.makePrediction("iris.data2_test.txt");
	p.print();
	}
}
