package Classification;

/*
 * This hold each possible label for the types that are being predicted
 * together with true or false counts for each of these parameters
 */


public class SplitCount {
	public String[] parameter_names;
	public int[] true_count;
	public int[] false_count;
	
public	SplitCount(String[] p) {
	parameter_names=p;
	true_count=new int[p.length];
	false_count=new int[p.length];
}

//returns null if no prediction
public String getPrediction(boolean true_false) {
	
	//just use single max value from leaf node
	boolean maxv=false;
	int max=0;
	int index=0;
	for(int loop=0;loop<parameter_names.length;loop++) {
		if(true_count[loop]>max) {max=true_count[loop];maxv=true;index=loop;}
		if(false_count[loop]>max){max=false_count[loop];maxv=false;index=loop;}
	}
	
	if(true_false==maxv) {
		return parameter_names[index];
	}
	
	return null;//if ask for non-prediction
}

public void add(String param,boolean tf) {
	
//find param- here assumed parameter_names is a small array
//so no performance issues here...
	for(int i=0;i<parameter_names.length;i++) {
	if(parameter_names[i].equals(param)) {
		if(tf) {
			true_count[i]++;
		}else {
			false_count[i]++;
		}
		
		break;
	}
}
	
}

public String getDot() {
	StringBuffer b=new StringBuffer();
	
	b.append("|{");
	
	
	for(int i=0;i<parameter_names.length;i++) {
		b.append(parameter_names[i]);
		b.append(" T ");
		b.append(true_count[i]);
		b.append(" F ");
		b.append(false_count[i]);
		if(i<parameter_names.length -1)b.append("|");
	}
	b.append("}|");
	return b.toString();
}

public void print() {
	for(int i=0;i<parameter_names.length;i++) {
		System.out.printf("%s T-%d F-%d\n", parameter_names[i],true_count[i],false_count[i]);
	}
}

boolean isIdentical(SplitCount s) {
	
if(parameter_names.length!=s.parameter_names.length)return false;
if(true_count.length!=s.true_count.length)return false;
if(false_count.length!=s.false_count.length)return false;

for(int loop=0;loop<parameter_names.length;loop++) {//arrays all same length
	if(parameter_names[loop]!=s.parameter_names[loop])return false;
	if(true_count[loop]!=s.true_count[loop])return false;
	if(false_count[loop]!=s.false_count[loop])return false;
}

	
return true;	
}

//proportion one group
double proportionOneGroup() {
	
	//uninteresting groups ill be close to 0
	//interesting in just one or to splits
	
	int max=0;
	int count=0;
	
	for(int i=0;i<parameter_names.length;i++) {
		if(false_count[i]>max)max=false_count[i];
		if(true_count[i]>max)max=true_count[i];
		count+=false_count[i];
		count+=true_count[i];
	}
	
	return ((double)max/(double)count);
}



}
