package Classification;

import java.io.PrintWriter;
import java.util.Arrays;

/*
 * This class represents a single node in the decision tree
 * As this is a simple structure, two edges (leftNode, rightNode) are 
 * stored for each mode-these can both be connected to other elements
 * (internal binary node), one element or no further elements (leaf node)
 * 
 * Nodes can  write themselves as part of a GraphViz output format
 * Nodes can record when they are initialised, visited or are leaf nodes
 * Leaf nodes are used for prediction in Decision trees
 * 
 */

public class Node {

private Node leftNode=null;//true
private Node rightNode=null;//false
private int parameter;
private double less_than;
private boolean visited;
private int node_index=-1;//index for the node
private SplitCount splitcount=null;
private int[] indexes=null;
private boolean terminated=false;//set when split is reached
private boolean initialised=false;

public boolean getTerminated() {return terminated;}
public void setTerminated(boolean t) {terminated=t;}

public SplitCount getSplitCount() {return splitcount;}
public void setSplitCount(SplitCount sc) {splitcount=sc;}

public Node(int p,double lt){this.init(p, lt);}

public String getLabel() {
	return ("node"+node_index);
}

public Node() {}

public void init(int p,double lt){
	parameter=p;less_than=lt;
	initialised=true;	
}

public int getNodeIndex() {return node_index;}
public void setNodeIndex(int i) {node_index=i;}

public void setIndexes(int[] idx) {
	indexes=idx;
}

public int[] getIndexes() {
	return indexes.clone();
}

public Node getLeftNode() {return leftNode;}
public Node getRightNode() {return rightNode;}

public void setLeftNode(Node x) {leftNode=x;}
public void setRightNode(Node y) {rightNode=y;}

public double getLessThan() {return less_than;}
public int getParameter() {return parameter;}

public boolean getVisited() {return visited;}
public void setVisited(boolean v) {visited=v;}

public void print(String []classlabels) {
	System.out.println("Parameter: "+parameter);
	if(classlabels!=null)System.out.println("Parameter name: "+classlabels[parameter]);
	System.out.println("Visited: "+visited);
	System.out.println("Less_than: "+less_than);
	System.out.println("Node Index: "+node_index);
	if(leftNode!=null) {
		System.out.println("Left Node: " +leftNode.getNodeIndex());	
	}else {
		System.out.println("Left Node: null");
	}
	if(rightNode!=null) {
		System.out.println("Right Node: " +rightNode.getNodeIndex());
	}else {
		System.out.println("Right Node: null");
	}
	
	//print the splitcount if it exists
	if(splitcount!=null) {
		System.out.println("Split count for this node");
		splitcount.print();
	}
	
	//terminated status
	if(terminated) {
		System.out.println("Terminated node");
	}else {
		System.out.println("Not yet terminated node");
	}
	
	//initialised
	if(initialised) {
		System.out.println("Initialised node");
	}else {
		System.out.println("Not yet initialised node");
	}
	
}
//http://www.webgraphviz.com/
public void writeDot(PrintWriter p,boolean getNode, String[] classlabels) {
	
	String scount=" ";
	if(splitcount!=null) {
		scount=splitcount.getDot();
	}
	
	if(!initialised) {
		p.write(getLabel()+"[label=\""+getLabel() +"\",");
		p.write(" shape=record ];\n");
		return;
	}
	
	
	
	
	if(getNode) {
		
		//terminated
	//	if(terminated) {
	//		p.write(getLabel()+"[label=\""+getLabel() +"|{|terminated:"+terminated+"}|"+ scount+"\",");
	//		p.write(" shape=record ];\n");
	//		return;
	//	}	
		
		
	p.write(getLabel()+"[label=\""+getLabel() +"| {param:"+classlabels[parameter]+"|less_than:"+less_than+"|terminated:"+terminated+"}|"+ scount+"\",");
	p.write(" shape=record ];\n");
	
	}else {
	
	if(getLeftNode()!=null) {
		p.write(getLabel()+ " -> "+getLeftNode().getLabel()+"[label=\"< "+less_than+"\"];\n");
	}
	
	if(getRightNode()!=null) {
		p.write(getLabel()+ " -> "+getRightNode().getLabel()+"[label=\">= "+less_than+"\"];\n");
	}
	
	}
	
	
	
}

}
