package Classification;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;

//this holds the input data from tab-delimited file
//table is of fixed size so use built-in arrays internally to hold the data
//error checking code omitted for simplicity

public class ClassTable {
private	String [] header_names;
private int class_index;
private double[][] values;
private String filename;
private String []classnames;
private String[] rowclasslabel;

private int countLines(String fname ) {
	
	try {
	Path path = Paths.get(fname);
	return  (int)Files.lines(path).count();	
	}catch (IOException e) {
		System.err.println("Error:  Unable to count lines");
		return 0;
	}
}

private int parseHeader(String header) {
	
	header_names =header.split("\t");
	
	class_index=-1;
	
	//try to set the class index
	for(int loop=0;loop<header_names.length;loop++) {
		if(header_names[loop].toLowerCase().equals("class")) {
			class_index=loop;
		}
	}
	
	System.out.println("Class index "+ class_index);
		
	return header_names.length;
}


private void clear() {
	header_names=null;
	class_index=-1;
	values=null;
}

private void setClassNames() {
	classnames=null;
	
	StringBuffer tmp_names =new StringBuffer();
	
	for(int loop=0;loop<rowclasslabel.length;loop++) {
		
		if(!tmp_names.toString().contains(rowclasslabel[loop])) {
			tmp_names.append(rowclasslabel[loop]);
			tmp_names.append("\t");
		}
		
	}
	
	//remove the last tab
	if(tmp_names.length()>0)tmp_names.deleteCharAt(tmp_names.length()-1);

	classnames=tmp_names.toString().split("\t");
	
	System.out.println("Classnames: "+Arrays.toString(classnames));
	
}
//these are the different classes
public String[] getClassNames() {
	return classnames.clone();
}
//these are the classifications for each row
public String[] getRowClassLabels() {
	return rowclasslabel.clone();
}

public double[][] getValues() {
	return values.clone();
}

public int getClassIndex() {
	return class_index;
}

public String[] getHeaderNames() {
	return header_names.clone();
}
	
public ClassTable(){}

public void parse(String fname) {
	boolean firstline=false;
	filename=fname;
	
	//tidy up from previous loads
	clear();
	
	
	try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
	    String line;
	    
	    //deal with the header
	    line = br.readLine();
	    if(line!=null) {
	    	int header_size=parseHeader(line);
	    	int row_count=countLines(filename);
	    	
	    	System.out.println("Counts- Header: "+header_size+ " Row: "+row_count);
	    	
	    	//create the storage
	    	values=new double[row_count-1][header_size];
	    	rowclasslabel =new String[row_count-1];
	    	
	    	
	    	
	    }else {
	    	System.err.println("Error: Unable to parse file header: "+filename);
			return;
	    }
	    
	    int linecount=0;
	    while ((line = br.readLine()) != null && firstline==false) {
	       // process each line.
	       String[] aline=line.split("\t");
	       
	       for(int loop=0;loop<aline.length;loop++) {
	    	   
	    	   if(loop==class_index) {
	    		   rowclasslabel[linecount]=aline[class_index];
	    	   }else {
	    	   values[linecount][loop]=Double.parseDouble(aline[loop]);
	    	   }
	       }
	       linecount++;
	        	
	    	
	    }
	    
	  //set the Classnames
    	setClassNames();
    	
    	//check classnames is set
    	if(class_index==-1) {System.out.println("Cannot parse- no class");return;}
	    
	    
	}catch(IOException e) {
		System.err.println("Error: Unable to parse file: "+filename);
		return;
	}
	

	
}

public void printTable() {
	
	System.out.println("Class Index Column: "+class_index);
	System.out.println("Header Names: "+Arrays.toString(header_names));
	System.out.println("Class Names: "+Arrays.toString(classnames));
	System.out.println("----");
	
	for(int loop=0;loop<header_names.length;loop++) {
		System.out.print(header_names[loop]);
		System.out.print("\t");
	}
	System.out.print("\n");
	
	for(int loop=0;loop<values.length;loop++) {
		
		for(int looper=0;looper<values[loop].length;looper++) {
			if(looper==class_index) {
			System.out.print(rowclasslabel[loop]);
			System.out.print("\t");
			}else {
			System.out.print(values[loop][looper]);
			System.out.print("\t");
			}
		}
		System.out.print("\n");
		
		
	}
	
}


}
