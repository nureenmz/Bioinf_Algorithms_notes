package Classification;

/*
 * This is used to store the build-in arrays of indexes used to feed selected
 * rows further down the binary tree
 */

public class Splits {
	Splits(){leftSplit=null;rightSplit=null;}
public int[] leftSplit;
public int[] rightSplit;
}
