package Classification;

/*
 * Makes a prediction using the CART generated decision tree
 * Traverse the tree following decision rules until terminal leaf
 * node is reached- this then provides the prediction
 */

public class SimplePrediction {
	
	private CARTDecisionTree decision_tree;
	
	
public SimplePrediction(CARTDecisionTree dt){
decision_tree=dt;	
}

public PredictionResults makePrediction(String filename) {
	

//read in the prediction table
ClassTable prediction_table= new ClassTable(); 
prediction_table.parse(filename);

double[][] values=prediction_table.getValues();
String [] labels =prediction_table.getRowClassLabels();
//here we assume classname labels are in the same order in both tables!

PredictionResults res =new PredictionResults(values.length);

//for each row in the prediction_table make a qualitative prediction
int count=0;
for(int loop=0;loop<values.length;loop++) {
	String predicted=decision_tree.predict(values[loop]);
	String expected=labels[loop];
	res.add(predicted,expected);
	
}
	
return res;	
}


}
