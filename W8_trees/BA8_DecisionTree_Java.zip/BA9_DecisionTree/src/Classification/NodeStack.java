package Classification;

/*
 * This is a simple stack used to store and organise nodes during tree traversal
 */

public class NodeStack {
public NodeStack(){
	mynodes=new Node[capacity];
}

public void push(Node x) {
	mynodes[current_index]=x;
	current_index++;
	if(current_index==capacity)growContainer();
}

public Node pop() {
	if(current_index==0)return null;
    current_index--;
    Node v=mynodes[current_index];
    mynodes[current_index]=null;
    return v;	
}
	

private void growContainer() {
	
Node mynodes2[]=new Node[capacity*2];

for(int loop=0;loop<capacity;loop++) {mynodes2[loop]=mynodes[loop];}
capacity=capacity*2;
mynodes=mynodes2;
	
}

int getCurrentSize() {return current_index;}

Node[] getNodes() {
	
	if(current_index==0)return null;
	
	Node[] nodes=new Node[current_index];
	
	for(int loop=0;loop<current_index;loop++) {
		nodes[loop]=mynodes[loop];
	}
	
	return nodes;
}

private Node[] mynodes;	
private int capacity=10;
private int current_index=0;
}
