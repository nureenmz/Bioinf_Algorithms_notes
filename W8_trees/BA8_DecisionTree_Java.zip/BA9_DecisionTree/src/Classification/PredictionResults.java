package Classification;

/*
 * Holds and prints classification results
 */
public class PredictionResults {
	
private String[] predicted=null;
private String[] expected=null;
private int count=0;
	
public 	PredictionResults(int x){
	predicted=new String[x];
	expected=new String[x];	
}
public void add(String pre,String exp) {
	predicted[count]=pre;
	expected[count]=exp;
	count++;
}
public 	void print(){
	
	int cc=0;
	
	for(int i=0;i<count;i++) {
	System.out.println("Index: "+i +" Predicted: "+predicted[i] + " Expected: "+expected[i]);
	if(predicted[i]!=null && predicted[i].equals(expected[i]))cc++;
	}
	
	//overall prediction
	System.out.printf("Overall prediction percentage: %.2f\n",(double)cc/(double)count);

}
}
