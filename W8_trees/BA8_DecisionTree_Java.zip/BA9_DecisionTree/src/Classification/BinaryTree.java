package Classification;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/*
 * This class encodes a simple Binary tree used as a data structure for the
 * Decision Tree
 */

public class BinaryTree {
	
private  Node []nodes;//nodes are stored internally
private int nodecount=0; //the current count of nodes in the objec
private int max_depth; 
private String[] classlabels=null;

private void deleteRebuild(Node x) {
	
//just rebuild the data structure missing node x
//deletion of a fixed array is costly!
//tree indexes have already been corrected- here just adjust data strcture

if(nodecount==0||x==null)return;
if(nodes[x.getNodeIndex()-1]!=x)return; //different tree
	
Node [] nodes2= new Node[nodecount-1];
int currentpos=0;

for(int i=0;i<nodecount;i++) {
	if(nodes[i].getNodeIndex()==x.getNodeIndex())continue;
	nodes2[currentpos]=nodes[i];
	currentpos++;	
}

nodes=nodes2;
nodecount--;
	
}

//Nodes need to be removed from the tree as well as from the storage array
public void deleteLeafNode(Node x) {
	//nodeindex is +1 array index of the node
	if(x.getLeftNode()!=null||x.getRightNode()!=null) {
		System.err.println("Oops: Node is not leaf-cannot delete "+ x.getNodeIndex());
	return;
	}
	
	//set the parent to no longer connect
	Node n =this.getParent(x);
	if(n==null) {
		System.err.println("Oops:  Node not part of binary tree!2 "+x.getNodeIndex());
		return;
	}
	if(n.getLeftNode().getNodeIndex()==x.getNodeIndex()) {
		n.setLeftNode(null);
	}
	
	if(n.getRightNode().getNodeIndex()==x.getNodeIndex()) {
		n.setRightNode(null);
	}
	
	deleteRebuild(x);
	
	
}

//store row class labels
public void setClassLabels(String [] lab) {
	classlabels=lab;
}

//just used to print out some nodes to the console
public  void printNodes(Node[] x) {
	
	System.out.println("");
	System.out.println("Nodes ...");
	
	for(int loop=0;loop<x.length;loop++) {
		x[loop].print(classlabels);
		System.out.println("\n");
	}
}

//constucture used to create the binary tree-in theory tree can be overloaded
public	BinaryTree(){
		initTree(5);
		}

//root node is key- all traversals start at the root
public void setRootNode(Node x) {
	nodes[0]=x;
	nodecount=1;
	nodes[0].setNodeIndex(nodecount);
}

private void setVisited(boolean x) {
	for(int loop=0;loop<nodes.length;loop++) {
		nodes[loop].setVisited(x);
	}
}

public Node getRootNode() {
	return nodes[0];
}

//nodes can be trivially obtained from the array used to store the Nodes
public Node getNode(int index) {//first index is 1
	                          //nodecount is alays +1 end
	if(index<0||index>nodecount)return null;
	return nodes[index-1];
}

//to go up the tree is tricky as the binary tree does not store the parent
//it can be obtained by iterating the array used to store the nodes
public Node getParent(Node n) {
	
	if(n==null)return null;
//just search for the parent node from the start of the array
for(int i=0;i<nodecount;i++) {
	
	Node t =nodes[i].getLeftNode();
	if(t!=null) {
		int idx =t.getNodeIndex();
		if(n.getNodeIndex()==idx)return nodes[i];
	}
	
	t =nodes[i].getRightNode();
	if(t!=null) {
		int idx =t.getNodeIndex();
		if(n.getNodeIndex()==idx)return nodes[i];
	}
	
}
return null;
}

//get leaf nodes that are not terminated to continue with the tree build
public Node[] getLeafNonTerminatedNodes() {
	Node[] n=this.getLeafNodes();
	//first count the non-terminated leaf nodes
	int count=0;
	for(int i=0;i<n.length;i++) {
	if(n[i].getTerminated()==false)count++;	
	}
	
	if(count==0)return null;//nothing to do
	
	//otherwise create memory and build results
	Node[] res=new Node[count];
	
	count=0;
	for(int i=0;i<n.length;i++) {
		if(n[i].getTerminated()==false) {
			res[count]=n[i];
			count++;
		}
		}

	return res;
	
}

public Node[] getLeafNodes() {//just traverse tree until reach leaf nodes
	                  //leaf nodes have no left or right nodes

NodeStack stack =new NodeStack();
NodeStack store_leaves =new NodeStack();

Node n =this.getRootNode();
if(n==null)return null;

stack.push(n);

while(stack.getCurrentSize()>0) {
	Node v=stack.pop();
	Node lnode;
	Node rnode;
	
	lnode=v.getLeftNode();
	rnode=v.getRightNode();
	
	if(lnode!=null)stack.push(lnode);
	if(rnode!=null)stack.push(rnode);
	
	if(lnode==null && rnode==null)store_leaves.push(v);
}

//return the final leaf nodes
return store_leaves.getNodes();

	
}


//this adds leaf nodes to a node (add) already in the tree
public boolean addNodeSplit(Node add, Node leftnode,Node rightnode) {
	
	//TODO grow the tree here
	if(nodes.length<=nodecount+2)return false;//full
	
	//only add if not already carrying a node split
	if(add.getLeftNode()!=null || add.getRightNode()!=null)return false;
	
	if(leftnode!=null) {
	nodes[nodecount]=leftnode;
	nodecount++;
	leftnode.setNodeIndex(nodecount);
	leftnode.setLeftNode(null);//must be added as a leaf
	leftnode.setRightNode(null);
	add.setLeftNode(leftnode);
	}
	if(rightnode!=null) {
	nodes[nodecount]=rightnode;
	nodecount++;
	rightnode.setNodeIndex(nodecount);
	rightnode.setLeftNode(null);//must be added as a leaf
	rightnode.setRightNode(null);
	add.setRightNode(rightnode);
	}
	
	return true;
}

//create a tree that can handle 5 levels of binary tree (by default)
public	void initTree(int mdepth){
	if(mdepth>10)max_depth=10; else max_depth=mdepth;
	
		nodes=new Node[(int)Math.pow(2,max_depth)-1];
		
	}
	

//just print out the nodes to the screen
public void printTree() {
	//just print the nodes
	for(int loop=0;loop<nodecount;loop++) {
		System.out.println("\nNode "+(loop+1));
		nodes[loop].print(classlabels);
	}
	
}

//writes a Dot format file -ith a default name
public void writeDotTree() {
	this.writeDotTree("binary_tree.gv");
}

public void writeDotTree(String filename) {
	//write out a tree for viewing as a DOT file in GraphViz
	try(PrintWriter pw = new PrintWriter(new FileWriter(filename))){
		
	pw.write("digraph mytree {\n");
	pw.write("size = "+"\"30,30!\"\n");
	 
	for (int i = 0; i < nodecount; i++) {
		nodes[i].writeDot(pw,true,classlabels);
	}
	for (int i = 0; i < nodecount; i++) {
		nodes[i].writeDot(pw,false,classlabels);
	}
	
	pw.write("}\n");
 
	pw.close();
	}catch(IOException e) {
	System.err.println("Error: Unable to write "+ filename);
	return;
}

}

}