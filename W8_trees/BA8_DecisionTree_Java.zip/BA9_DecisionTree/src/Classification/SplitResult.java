package Classification;

/*
 * This holds the result of the CART search for a split
 * parameter is the index of each parameter used
 * bestsplit is the condition used with <
 * best score is the best score (best gini index here)
 */

public class SplitResult {
public	SplitResult(){parameter=-1;bestsplit=0;bestscore=1;}
public	SplitResult(int p,double b, double bs){
		parameter=p;
		bestsplit=b;
		bestscore=bs;
	}
	
	public void print(String x[]) {
		System.out.println("Parameter: "+parameter);
		System.out.println("Parameter: "+x[parameter]);
		System.out.println("Bestsplit: "+bestsplit);
		System.out.println("Bestscore: "+bestscore);
		
	}
public int parameter;
public double bestsplit;
public double bestscore;
}
