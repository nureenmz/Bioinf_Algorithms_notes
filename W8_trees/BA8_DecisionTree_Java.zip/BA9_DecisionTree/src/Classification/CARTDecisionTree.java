package Classification;

/*
 * This class is responsible for building the decision tree and testing
 * classifications against the tree
 */
public class CARTDecisionTree {
private BinaryTree btree =new BinaryTree();
private ClassTable table=new ClassTable();
private double termination_threshold=0.90;

public void setTerminationThreshold(double p) {
	if(p<=0||p>1)return;
	termination_threshold=p;
}
	
public CARTDecisionTree(){}

private boolean testTermination(Node n) {

SplitCount sc=null;
//two tests-no change from parent
	Node pn =btree.getParent(n);
	if(pn!=null) {
	sc =pn.getSplitCount();
	}else {
		System.err.println("Error: Unable to retrieve parent");
		return false;
	}

	if(sc.isIdentical(n.getSplitCount()))return true;
	

//check if most ets are in one group
	double prop=n.getSplitCount().proportionOneGroup();
	if(prop>=termination_threshold)return true;
	
	
	

//mostly pure type in classification
//some classes do no appear in this subgraph
	SplitCount sc1=n.getSplitCount();
	
	if(sc1==null) {
		System.err.println("Error: Unable to retriece splitcount");
		return false;	
	}
	
	//loop through elements are compare T F groupings for parameters
	boolean foundsplit=false;
	for(int i=0;i<sc1.parameter_names.length;i++) {
		if(sc1.false_count[i]==0 && sc1.true_count[i]==0)continue;
		double v=(double)sc1.false_count[i]/(double)sc1.true_count[i];
		double vv=1/v;
		if(vv>=termination_threshold||v>=termination_threshold && foundsplit==false) {
			foundsplit=true;
			continue;
		}
		if(vv>=termination_threshold||v>=termination_threshold && foundsplit==true) {
			return false;
		}
		
	}
	if(foundsplit==true)return true;
	
return false;	
}

public ClassTable getClassTable() {return table;}

public BinaryTree getBinaryTree() {return btree;}

public Splits getSplits(int[] indexes, SplitResult s) {
//count the splits
	Splits sp=new Splits();
	
	double[][]values=table.getValues();
	
	int leftCount=0,rightCount=0;

	for(int i=0;i<indexes.length;i++) {
		double d=values[indexes[i]][s.parameter];
		if(d <s.bestsplit)leftCount++;else rightCount++;		
	}
	
	
	if(leftCount>0)sp.leftSplit=new int[leftCount];
	if(rightCount>0)sp.rightSplit=new int[rightCount];
	
	int countl=0,countr=0;
	for(int p=0;p<indexes.length;p++) {
		double d=values[indexes[p]][s.parameter];
		if(d<s.bestsplit) {
			sp.leftSplit[countl]=indexes[p];
			countl++;
		}else {
			sp.rightSplit[countr]=indexes[p];
			countr++;
			
		}
	}
	return sp;
}

public SplitCount countBestSplit(int[] indexes,SplitResult s) {
	
	//count the splits
	String [] names=table.getClassNames();
	double[][]values=table.getValues();
	String []classes=table.getRowClassLabels();
	
	SplitCount sc =new SplitCount(names);
	
	//now count everything
	for(int i=0;i<indexes.length;i++) {
		double d=values[indexes[i]][s.parameter];
		sc.add(classes[indexes[i]],d <s.bestsplit);
		
	}
	
	
	
	return sc;
}

private SplitResult grabBestSplit(int[] indexes) {
	
double less_than;
int parameter;
double gini;

//set initial values;
double best_gini_index=0;
int best_parameter=0;
double best_less_than=1;

double[][] vals =table.getValues();

for(int loop=0;loop<indexes.length;loop++) {
	for(int looper=0;looper<vals[loop].length;looper++) {
		parameter=looper;
		if(parameter==table.getClassIndex())continue;
		less_than=vals[indexes[loop]][looper];
		
		gini=giniIndex(indexes, less_than, parameter);
		
		//first loop
		if(looper==0 && loop==0) {
			best_gini_index=gini;
			best_parameter=parameter;
			best_less_than=less_than;
			continue;
		}
		
		if(gini<best_gini_index) {
			best_gini_index=gini;
			best_parameter=parameter;
			best_less_than=less_than;
		}
		
	}
	
	
}

//return the final results
return new SplitResult(best_parameter,best_less_than,best_gini_index);
	
}

private double giniIndex(int[] indexes,double less_than, int parameter ) {

double gini=1.0;//worst index
	
//grab table data-indexes are for this data data
double[][]v =table.getValues();

//grab classifications from table
String[] cl =table.getRowClassLabels();
	
//grab list of possible classifiers-variables for classifications
String[] classes =table.getClassNames();
	
//for each class calculate group1,group2, class1, class2
double group1[] =new double[classes.length];
double group2[] =new double[classes.length];
double sze_group1=0;
double sze_group2=0;
	
for(int loop=0;loop<indexes.length;loop++) {
	if(v[indexes[loop]][parameter]<less_than) {
		sze_group1++;
		
		for(int looper=0;looper<classes.length;looper++) {
			if(cl[indexes[loop]].equals(classes[looper])){
				group1[looper]+=1;
				}
		}
		
	}else {
		sze_group2++;
		
		for(int looper=0;looper<classes.length;looper++) {
			if(cl[indexes[loop]].equals(classes[looper])){
				group2[looper]+=1;
				}
		}
		
		
		
	}
	
	
}
//debug
//System.out.println("Sze groups:"+sze_group1+" "+sze_group2);


//bring it all together to calculate gini
double gini_g1,gini_g2;
double proportion=0.0;

//for first group
gini_g1=0;
for(int loop=0;loop<classes.length;loop++) {
	
	proportion=group1[loop]/(sze_group1+0.01);
	gini_g1+=proportion*proportion;
}
gini_g1=(1-gini_g1)*sze_group1/(sze_group1+sze_group2);
	
//for second group
gini_g2=0;
for(int loop=0;loop<classes.length;loop++) {
	
	proportion=group2[loop]/(sze_group2+0.01);
	gini_g2+=proportion*proportion;
}
gini_g2=(1-gini_g2)*sze_group2/(sze_group1+sze_group2);

gini=gini_g1+gini_g2;
	
return gini;	
}

public void buildTree(String flename) {
	
//read table
table.parse(flename);

//create a table of indexes -table is RC;

int len=table.getRowClassLabels().length;
int []indexes=new int[len];

for(int loop=0;loop<len;loop++) {
	indexes[loop]=loop;
}

//grap the best split
SplitResult s=grabBestSplit(indexes);
//grap_best_split
s.print(table.getHeaderNames());

//count the split
SplitCount c = countBestSplit(indexes,s);
c.print();

//add to tree
Node n=new Node(s.parameter,s.bestsplit);


n.setSplitCount(c);
btree.setRootNode(n);
btree.setClassLabels(table.getHeaderNames());

//set the class split
Splits split;

split=getSplits(indexes,s);

//store these node splits for future analysis in the node elements
Node n1=new Node();
Node n2=new Node();

n1.setIndexes(split.leftSplit);
n2.setIndexes(split.rightSplit);
btree.addNodeSplit(n, n1, n2);

//go through the tree adding nodes as required
Node[] nodes= btree.getLeafNonTerminatedNodes();

while(nodes!=null && nodes.length>0) {
	
    for(int i=0;i<nodes.length;i++) {
    indexes=nodes[i].getIndexes();
    
    
	s=grabBestSplit(indexes);
	c = countBestSplit(indexes,s);
	nodes[i].init(s.parameter,s.bestsplit);//add back to ree use init
	nodes[i].setSplitCount(c);
	
	 if(testTermination(nodes[i])){
			nodes[i].setTerminated(true);
			continue;
		}
	
	//otherwise process the potential node children
	Splits sp2=getSplits(nodes[i].getIndexes(),s);
	n1=new Node();
	n2=new Node();
	
	n1.setIndexes(sp2.leftSplit);
	n2.setIndexes(sp2.rightSplit);
	btree.addNodeSplit(nodes[i], n1, n2);
    }
    
    //run again for newly added nodes
    nodes=btree.getLeafNonTerminatedNodes();

}

//plot onto dot 
btree.writeDotTree("second_tree.gv");
}
	
public String predict(double[] values) {
	String temp="";

Node n=btree.getRootNode();

//move down the binary tree matching as go
while(n.getTerminated()==false) {
	if(values[n.getParameter()]<n.getLessThan()){
	n=n.getLeftNode();
	}else {
	n=n.getRightNode();
	}
}

//finally make the prediction
return n.getSplitCount().getPrediction(values[n.getParameter()]<n.getLessThan());
}
	
}
